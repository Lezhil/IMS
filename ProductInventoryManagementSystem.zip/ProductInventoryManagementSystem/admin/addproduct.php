
<?php
include('db.php');

if(isset($_POST['productname']))
{
    $productname=$_POST['productname'];
    $retail=$_POST['retail'];
    $selling=$_POST['selling'];
    $stock=$_POST['stock'];

$sql="INSERT INTO `product`( `Product_name`, `Retail_Price`, `Selling_price`, `Stock`) VALUES ('$productname','$retail','$selling','$stock')";
if(mysqli_query($con,$sql)){
    echo "Product added successfully";
}
else{
    echo "something went wrong";
}
}
?><!doctype html>
<html lang="en">


<!-- Mirrored from demo.dashboardpack.com/kero-html-sidebar-pro/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 25 Dec 2020 03:21:50 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Inventory Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"
    />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <link rel="icon" href="favicon.ico">

    <!-- Disable tap highlight on IE -->
    <meta name="msapplication-tap-highlight" content="no">

<link href="main.07a59de7b920cd76b874.css" rel="stylesheet"></head>
<body>
<div class="app-container app-theme-gray">
        <div class="app-main">
            <div class="app-sidebar-wrapper">
                <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                       
                        <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                        </button>
                    </div>
                    <div class="scrollbar-sidebar scrollbar-container">
                        <div class="app-sidebar__inner">
                            <ul class="vertical-nav-menu">
                                <li class="app-sidebar__heading">Menu</li>
                                <li
                                     class="mm-active"
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                >
                                    
                                    <ul
                                         class="mm-show"
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    >
            
            
                                        <li><a   href="index.php">Home</a></li>
                                        <li><a class="mm-active" href="addproduct.php">Add Product</a></li>
                                        <li><a href="addpurchase.php">Add Purchase</a></li>
                                        <li><a href="purchase.php">Purchase Details</a></li>
                                       
                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="app-sidebar-overlay d-none animated fadeIn"></div>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="header-mobile-wrapper">
                        <div class="app-header__logo">
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="KeroUI Admin Template" class="logo-src"></a>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-sidebar-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                            <div class="app-header__menu">
                            <span>
                                <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                    <span class="btn-icon-wrapper">
                                        <i class="fa fa-ellipsis-v fa-w-6"></i>
                                    </span>
                                </button>
                            </span>
                            </div>
                        </div>
                    </div>
                    <div class="app-header">
                        <div class="page-title-heading">
                            Inventory Management System
                            
                        </div>
                        
                        <div class="app-header-overlay d-none animated fadeIn"></div>
                    </div>
                    <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Add Product</h5>
                            <form method="post">
                                <div class="position-relative form-group"><label
                                        for="exampleEmail" class="">Product Name</label><input
                                        name="productname"
                                         type="text"
                                        class="form-control"></div>
                                        <div class="input-group position-relative">
                                       
                                                                    <div class="input-group-prepend"><span
                                                                            class="input-group-text">Rs.</span></div>
                                                                    <input name="retail" placeholder="Retail price" type="number"
                                                                           class="form-control"></div><br>

                                        <div class="input-group position-relative">
                                       
                                       <div class="input-group-prepend"><span
                                               class="input-group-text">Rs.</span></div>
                                       <input name="selling" placeholder="Selling price" type="number"
                                              class="form-control"></div><br>
                                               
                                       <div class="input-group-prepend"></div>
                                       <input name="stock" placeholder="Available stock" type="number"
                                              class="form-control"></div>
                                
                                
                                
                                
                                              <button type="submit" class="mt-1 btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>

<div class="app-drawer-overlay d-none animated fadeIn"></div>
<script type="text/javascript" src="assets/scripts/main.07a59de7b920cd76b874.js"></script></body>

<!-- Mirrored from demo.dashboardpack.com/kero-html-sidebar-pro/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 25 Dec 2020 03:22:31 GMT -->
</html>
