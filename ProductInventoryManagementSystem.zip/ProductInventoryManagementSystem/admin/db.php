<?php

$con=mysqli_connect('localhost','root','','ims');


?>